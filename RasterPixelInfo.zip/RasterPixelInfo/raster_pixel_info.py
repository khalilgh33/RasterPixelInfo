# -*- coding: utf-8 -*-
"""
RasterPixelInfo - QGIS Plugin
Displays row/column indices AND pixel values on raster pixels as you zoom in.
Includes multi-layer comparison panel and pixel border overlay.
"""

import os
from qgis.PyQt.QtWidgets import (
    QAction, QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QComboBox, QGroupBox, QCheckBox, QSpinBox, QFormLayout,
    QSizePolicy, QScrollArea, QTableWidget, QTableWidgetItem,
    QHeaderView, QPushButton, QFrame
)
from qgis.PyQt.QtCore import Qt, QTimer, QRectF
from qgis.PyQt.QtGui import QColor, QFont, QPainter, QPen, QBrush, QFontMetrics, QIcon
from qgis.core import (
    QgsRasterLayer, QgsProject, QgsPointXY,
    QgsCoordinateTransform, QgsRaster
)
from qgis.gui import QgsMapCanvasItem


# ──────────────────────────────────────────────────────────────────────────────
# Canvas overlay
# Each label entry: (cx, cy, row, col, values, pw, ph)
#   cx/cy   = screen center of pixel
#   row/col = 0-indexed raster coordinates
#   values  = list of float band values
#   pw/ph   = pixel size in screen pixels
# ──────────────────────────────────────────────────────────────────────────────
class PixelLabelItem(QgsMapCanvasItem):
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self._labels = []
        self.show_borders = True
        self.show_labels  = True
        self.show_values  = True
        self.setZValue(100)

    def set_labels(self, labels):
        self._labels = labels
        self.update()

    def clear(self):
        self._labels = []
        self.update()

    def boundingRect(self):
        return QRectF(0, 0, self.canvas.width(), self.canvas.height())

    def paint(self, painter, option, widget):
        if not self._labels:
            return
        painter.setRenderHint(QPainter.Antialiasing, False)

        font_rc  = QFont("Monospace", 7);  font_rc.setBold(True)
        font_val = QFont("Monospace", 6);  font_val.setBold(False)
        fm_rc    = QFontMetrics(font_rc)
        fm_val   = QFontMetrics(font_val)

        col_rc       = QColor(255, 255, 0)        # yellow — row/col label
        col_val      = QColor(120, 220, 255)      # cyan   — value
        bg_label     = QColor(0, 0, 0, 170)
        bg_val       = QColor(0, 0, 0, 150)
        col_tag_bdr  = QColor(255, 255, 255, 60)

        for (cx, cy, row, col, values, pw, ph) in self._labels:
            px_left  = int(cx - pw / 2)
            px_top   = int(cy - ph / 2)
            px_w     = int(pw)
            px_h     = int(ph)

            # ── 1. Pixel border (independent) ─────────────────────────────
            if self.show_borders:
                border_pen = QPen(QColor(255, 80, 80, 200), 1.0)
                border_pen.setCosmetic(True)
                painter.setPen(border_pen)
                painter.setBrush(Qt.NoBrush)
                painter.drawRect(px_left, px_top, px_w, px_h)

            # ── 2. Row/col tag — sits on the top-left corner of the pixel ─
            if self.show_labels:
                rc_text = f"r{row} c{col}"
                rc_w = fm_rc.horizontalAdvance(rc_text)
                rc_h = fm_rc.height()
                tag_w = rc_w + 4
                tag_h = rc_h + 2
                # anchor to pixel top-left, offset inward by 1px
                tx = px_left + 1
                ty = px_top  + 1
                painter.setPen(QPen(col_tag_bdr, 0.5))
                painter.setBrush(QBrush(bg_label))
                painter.drawRect(tx, ty, tag_w, tag_h)
                painter.setFont(font_rc)
                painter.setPen(QPen(col_rc))
                painter.drawText(tx + 2, ty + rc_h - 1, rc_text)

            # ── 3. Pixel value — centered inside the pixel ─────────────────
            if self.show_values and values:
                if len(values) == 1:
                    val_text = f"{values[0]:.4g}"
                else:
                    val_text = "  ".join(f"B{i+1}:{v:.4g}" for i, v in enumerate(values))
                val_w = fm_val.horizontalAdvance(val_text)
                val_h = fm_val.height()
                vbox_w = val_w + 6
                vbox_h = val_h + 4
                vx = int(cx - vbox_w / 2)
                vy = int(cy - vbox_h / 2)
                painter.setPen(QPen(col_tag_bdr, 0.5))
                painter.setBrush(QBrush(bg_val))
                painter.drawRect(vx, vy, vbox_w, vbox_h)
                painter.setFont(font_val)
                painter.setPen(QPen(col_val))
                painter.drawText(vx + 3, vy + val_h, val_text)


# ──────────────────────────────────────────────────────────────────────────────
# Dock panel
# ──────────────────────────────────────────────────────────────────────────────
class PixelInfoDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__("Raster Pixel Info", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self._build_ui()

    def _build_ui(self):
        container = QWidget()
        main_layout = QVBoxLayout(container)
        main_layout.setSpacing(6)

        # ── Primary layer selector ────────────────────────────────────────
        layer_group = QGroupBox("Primary Raster Layer")
        layer_form = QFormLayout(layer_group)
        self.layer_combo = QComboBox()
        self.layer_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        layer_form.addRow("Layer:", self.layer_combo)
        main_layout.addWidget(layer_group)

        # ── Current pixel info ────────────────────────────────────────────
        info_group = QGroupBox("Current Pixel (mouse position)")
        info_form = QFormLayout(info_group)
        self.lbl_row = QLabel("—")
        self.lbl_col = QLabel("—")
        self.lbl_val = QLabel("—")
        self.lbl_res = QLabel("—")
        self.lbl_map = QLabel("—")
        bold = QFont(); bold.setBold(True)
        for lbl in [self.lbl_row, self.lbl_col, self.lbl_val]:
            lbl.setFont(bold)
        info_form.addRow("Row (line):",      self.lbl_row)
        info_form.addRow("Column (sample):", self.lbl_col)
        info_form.addRow("Pixel value(s):",  self.lbl_val)
        info_form.addRow("Pixel resolution:", self.lbl_res)
        info_form.addRow("Map coords:",      self.lbl_map)
        main_layout.addWidget(info_group)

        # ── Layer comparison ──────────────────────────────────────────────
        cmp_group = QGroupBox("Layer Comparison")
        cmp_layout = QVBoxLayout(cmp_group)

        hint = QLabel("Check layers to compare pixel values at the same location:")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: gray; font-size: 10px;")
        cmp_layout.addWidget(hint)

        self._cmp_scroll = QScrollArea()
        self._cmp_scroll.setWidgetResizable(True)
        self._cmp_scroll.setMaximumHeight(130)
        self._cmp_scroll.setFrameShape(QFrame.StyledPanel)
        self._cmp_inner = QWidget()
        self._cmp_inner_layout = QVBoxLayout(self._cmp_inner)
        self._cmp_inner_layout.setSpacing(2)
        self._cmp_inner_layout.setContentsMargins(4, 4, 4, 4)
        self._cmp_scroll.setWidget(self._cmp_inner)
        cmp_layout.addWidget(self._cmp_scroll)

        btn_row = QHBoxLayout()
        self.btn_check_all = QPushButton("Check All");  self.btn_check_all.setFixedHeight(22)
        self.btn_clear_all = QPushButton("Clear All");  self.btn_clear_all.setFixedHeight(22)
        btn_row.addWidget(self.btn_check_all)
        btn_row.addWidget(self.btn_clear_all)
        cmp_layout.addLayout(btn_row)

        self.cmp_table = QTableWidget(0, 4)
        self.cmp_table.setHorizontalHeaderLabels(["Layer", "Row", "Col", "Value(s)"])
        self.cmp_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.cmp_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.cmp_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.cmp_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.cmp_table.setAlternatingRowColors(True)
        self.cmp_table.setMinimumHeight(100)
        self.cmp_table.verticalHeader().setVisible(False)
        cmp_layout.addWidget(self.cmp_table)
        main_layout.addWidget(cmp_group)

        # ── Display settings ──────────────────────────────────────────────
        settings_group = QGroupBox("Canvas Display Settings")
        settings_layout = QVBoxLayout(settings_group)

        self.chk_show_labels = QCheckBox("Show row/col labels on canvas")
        self.chk_show_labels.setChecked(True)
        settings_layout.addWidget(self.chk_show_labels)

        self.chk_show_values = QCheckBox("Show pixel values on canvas")
        self.chk_show_values.setChecked(True)
        self.chk_show_values.setToolTip(
            "Display band value(s) directly on each pixel.\n"
            "Shown in cyan below the row/col label."
        )
        settings_layout.addWidget(self.chk_show_values)

        self.chk_show_borders = QCheckBox("Show pixel borders on canvas")
        self.chk_show_borders.setChecked(True)
        self.chk_show_borders.setToolTip("Draw a red outline around every visible raster pixel.")
        settings_layout.addWidget(self.chk_show_borders)

        zoom_layout = QHBoxLayout()
        zoom_layout.addWidget(QLabel("Min zoom (screen px per raster px ≥):"))
        self.spin_min_px = QSpinBox()
        self.spin_min_px.setRange(5, 100)
        self.spin_min_px.setValue(20)
        self.spin_min_px.setToolTip(
            "Labels and values appear only when a raster pixel is at least this\n"
            "many screen pixels wide. Higher = need more zoom. Recommended: 20–40."
        )
        zoom_layout.addWidget(self.spin_min_px)
        settings_layout.addLayout(zoom_layout)

        main_layout.addWidget(settings_group)

        # ── Status ───────────────────────────────────────────────────────
        self.lbl_status = QLabel("Inactive")
        self.lbl_status.setAlignment(Qt.AlignCenter)
        self.lbl_status.setStyleSheet("color: gray; font-style: italic;")
        main_layout.addWidget(self.lbl_status)

        main_layout.addStretch()
        self.setWidget(container)
        self._cmp_checkboxes = {}

    # ── Public update methods ─────────────────────────────────────────────
    def update_pixel_info(self, row, col, values, res_x, res_y, map_x, map_y):
        self.lbl_row.setText(str(row))
        self.lbl_col.setText(str(col))
        val_str = "  |  ".join(f"B{i+1}: {v:.4g}" for i, v in enumerate(values)) if values else "N/A"
        self.lbl_val.setText(val_str)
        self.lbl_res.setText(f"{res_x:.4g} × {res_y:.4g} map units/px")
        self.lbl_map.setText(f"X: {map_x:.4f}  Y: {map_y:.4f}")

    def clear_pixel_info(self):
        for lbl in [self.lbl_row, self.lbl_col, self.lbl_val, self.lbl_res, self.lbl_map]:
            lbl.setText("—")

    def set_status(self, text, color="gray"):
        self.lbl_status.setText(text)
        self.lbl_status.setStyleSheet(f"color: {color}; font-style: italic;")

    def rebuild_comparison_checkboxes(self, raster_layers, changed_callback):
        prev_checked = {lid for lid, cb in self._cmp_checkboxes.items() if cb.isChecked()}
        while self._cmp_inner_layout.count():
            item = self._cmp_inner_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._cmp_checkboxes.clear()
        for layer in raster_layers:
            cb = QCheckBox(layer.name())
            cb.setChecked(layer.id() in prev_checked)
            cb.stateChanged.connect(changed_callback)
            self._cmp_inner_layout.addWidget(cb)
            self._cmp_checkboxes[layer.id()] = cb
        self._cmp_inner_layout.addStretch()

    def checked_layer_ids(self):
        return [lid for lid, cb in self._cmp_checkboxes.items() if cb.isChecked()]

    def set_all_checked(self, state):
        for cb in self._cmp_checkboxes.values():
            cb.setChecked(state)

    def update_comparison_table(self, rows):
        self.cmp_table.setRowCount(len(rows))
        for r, data in enumerate(rows):
            name_item = QTableWidgetItem(data["name"])
            name_item.setToolTip(data["name"])
            row_item  = QTableWidgetItem(str(data["row"]) if data["row"] is not None else "—")
            col_item  = QTableWidgetItem(str(data["col"]) if data["col"] is not None else "—")
            vals = data.get("values", [])
            val_str = " | ".join(f"B{i+1}:{v:.4g}" for i, v in enumerate(vals)) if vals else "out of extent"
            val_item = QTableWidgetItem(val_str)
            for item in [name_item, row_item, col_item, val_item]:
                item.setTextAlignment(Qt.AlignCenter)
            if data.get("is_primary"):
                for item in [name_item, row_item, col_item, val_item]:
                    item.setBackground(QColor(60, 120, 200, 60))
            self.cmp_table.setItem(r, 0, name_item)
            self.cmp_table.setItem(r, 1, row_item)
            self.cmp_table.setItem(r, 2, col_item)
            self.cmp_table.setItem(r, 3, val_item)
        self.cmp_table.resizeRowsToContents()

    def clear_comparison_table(self):
        self.cmp_table.setRowCount(0)


# ──────────────────────────────────────────────────────────────────────────────
# Main plugin class
# ──────────────────────────────────────────────────────────────────────────────
class RasterPixelInfo:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.dock = None
        self.label_item = None
        self.action = None
        self._active = False
        self._timer = QTimer()
        self._timer.setSingleShot(True)
        self._timer.setInterval(80)
        self._timer.timeout.connect(self._refresh_labels)
        self._last_mouse_pos = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
        self.action = QAction(icon, "Raster Pixel Info", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setToolTip("Toggle Raster Pixel Info panel and canvas labels")
        self.action.triggered.connect(self.toggle)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu("Raster Pixel Info", self.action)

        self.dock = PixelInfoDock(self.iface.mainWindow())
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.hide()

        self._populate_layer_combo()
        self._populate_comparison_checkboxes()

        QgsProject.instance().layersAdded.connect(self._on_project_layers_changed)
        QgsProject.instance().layersRemoved.connect(self._on_project_layers_changed)

        self.dock.layer_combo.currentIndexChanged.connect(self._on_layer_changed)
        self.dock.chk_show_labels.stateChanged.connect(self._on_settings_changed)
        self.dock.chk_show_values.stateChanged.connect(self._on_settings_changed)
        self.dock.chk_show_borders.stateChanged.connect(self._on_settings_changed)
        self.dock.spin_min_px.valueChanged.connect(self._on_settings_changed)
        self.dock.btn_check_all.clicked.connect(lambda: self.dock.set_all_checked(True))
        self.dock.btn_clear_all.clicked.connect(lambda: self.dock.set_all_checked(False))

    def unload(self):
        self._deactivate()
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginRasterMenu("Raster Pixel Info", self.action)
        if self.dock:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

    def toggle(self, checked):
        if checked:
            self._activate()
        else:
            self._deactivate()

    def _activate(self):
        self._active = True
        self.dock.show()
        self.action.setChecked(True)
        if self.label_item is None:
            self.label_item = PixelLabelItem(self.canvas)
        self._sync_label_item_flags()
        self.canvas.xyCoordinates.connect(self._on_mouse_move)
        self.canvas.scaleChanged.connect(self._on_scale_changed)
        self.canvas.mapCanvasRefreshed.connect(self._refresh_labels)
        self._populate_layer_combo()
        self._populate_comparison_checkboxes()
        self.dock.set_status("Active — move mouse over raster", "green")

    def _deactivate(self):
        self._active = False
        self.action.setChecked(False)
        for sig, slot in [
            (self.canvas.xyCoordinates,      self._on_mouse_move),
            (self.canvas.scaleChanged,       self._on_scale_changed),
            (self.canvas.mapCanvasRefreshed, self._refresh_labels),
        ]:
            try: sig.disconnect(slot)
            except Exception: pass
        if self.label_item:
            self.label_item.clear()
        if self.dock:
            self.dock.clear_pixel_info()
            self.dock.clear_comparison_table()
            self.dock.set_status("Inactive", "gray")

    def _sync_label_item_flags(self):
        if self.label_item and self.dock:
            self.label_item.show_borders = self.dock.chk_show_borders.isChecked()
            self.label_item.show_labels  = self.dock.chk_show_labels.isChecked()
            self.label_item.show_values  = self.dock.chk_show_values.isChecked()

    # ── Layer management ──────────────────────────────────────────────────
    def _raster_layers(self):
        return [
            l for l in QgsProject.instance().mapLayers().values()
            if isinstance(l, QgsRasterLayer) and l.isValid()
        ]

    def _populate_layer_combo(self, *args):
        if not self.dock: return
        combo = self.dock.layer_combo
        prev = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for layer in self._raster_layers():
            combo.addItem(layer.name(), layer.id())
        if prev:
            idx = combo.findData(prev)
            if idx >= 0: combo.setCurrentIndex(idx)
        combo.blockSignals(False)

    def _populate_comparison_checkboxes(self, *args):
        if not self.dock: return
        self.dock.rebuild_comparison_checkboxes(self._raster_layers(), self._on_comparison_changed)

    def _on_project_layers_changed(self, *args):
        self._populate_layer_combo()
        self._populate_comparison_checkboxes()

    def _active_layer(self):
        if not self.dock: return None
        lid = self.dock.layer_combo.currentData()
        if not lid: return None
        layer = QgsProject.instance().mapLayer(lid)
        if isinstance(layer, QgsRasterLayer) and layer.isValid():
            return layer
        return None

    def _on_layer_changed(self, *args):
        if self.label_item: self.label_item.clear()
        if self.dock: self.dock.clear_pixel_info()
        self._refresh_labels()

    def _on_comparison_changed(self, *args):
        if self._last_mouse_pos:
            self._update_dock_for_point(self._last_mouse_pos)

    # ── Events ────────────────────────────────────────────────────────────
    def _on_mouse_move(self, point):
        self._last_mouse_pos = point
        self._update_dock_for_point(point)
        self._timer.start()

    def _on_scale_changed(self, *args):
        self._timer.start()

    def _on_settings_changed(self, *args):
        self._sync_label_item_flags()
        self._refresh_labels()

    # ── Core computation ──────────────────────────────────────────────────
    def _pixel_size_on_screen(self, layer):
        mu = self.canvas.mapUnitsPerPixel()
        return layer.rasterUnitsPerPixelX() / mu if mu > 0 else 0

    def _map_point_to_layer_point(self, layer, map_point):
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs  = layer.crs()
        if canvas_crs != layer_crs:
            xform = QgsCoordinateTransform(canvas_crs, layer_crs, QgsProject.instance())
            return xform.transform(map_point)
        return map_point

    def _point_to_row_col(self, layer, layer_point):
        ext   = layer.extent()
        res_x = layer.rasterUnitsPerPixelX()
        res_y = layer.rasterUnitsPerPixelY()
        col = int((layer_point.x() - ext.xMinimum()) / res_x)
        row = int((ext.yMaximum() - layer_point.y()) / res_y)
        if 0 <= row < layer.height() and 0 <= col < layer.width():
            return row, col
        return None, None

    def _get_pixel_values(self, layer, row, col):
        ext   = layer.extent()
        res_x = layer.rasterUnitsPerPixelX()
        res_y = layer.rasterUnitsPerPixelY()
        x = ext.xMinimum() + (col + 0.5) * res_x
        y = ext.yMaximum() - (row + 0.5) * res_y
        result = layer.dataProvider().identify(QgsPointXY(x, y), QgsRaster.IdentifyFormatValue)
        values = []
        if result.isValid():
            for band in range(1, layer.bandCount() + 1):
                val = result.results().get(band)
                if val is not None:
                    try: values.append(float(val))
                    except (TypeError, ValueError): pass
        return values

    def _update_dock_for_point(self, map_point):
        if not self.dock: return
        primary    = self._active_layer()
        primary_id = self.dock.layer_combo.currentData()

        if primary:
            lp = self._map_point_to_layer_point(primary, map_point)
            row, col = self._point_to_row_col(primary, lp)
            if row is not None:
                values = self._get_pixel_values(primary, row, col)
                self.dock.update_pixel_info(
                    row, col, values,
                    primary.rasterUnitsPerPixelX(), primary.rasterUnitsPerPixelY(),
                    map_point.x(), map_point.y()
                )
            else:
                self.dock.clear_pixel_info()
        else:
            self.dock.clear_pixel_info()

        checked_ids = self.dock.checked_layer_ids()
        if not checked_ids:
            self.dock.clear_comparison_table()
            return

        all_layers  = {l.id(): l for l in self._raster_layers()}
        table_rows  = []
        for lid in checked_ids:
            layer = all_layers.get(lid)
            if not layer: continue
            lp = self._map_point_to_layer_point(layer, map_point)
            row, col = self._point_to_row_col(layer, lp)
            vals = self._get_pixel_values(layer, row, col) if row is not None else []
            table_rows.append({
                "name": layer.name(), "row": row, "col": col,
                "values": vals, "is_primary": (lid == primary_id),
            })
        self.dock.update_comparison_table(table_rows)

    # ── Canvas label + border refresh ─────────────────────────────────────
    def _refresh_labels(self):
        if not self._active or not self.label_item:
            return

        show_labels  = self.dock.chk_show_labels.isChecked()
        show_values  = self.dock.chk_show_values.isChecked()
        show_borders = self.dock.chk_show_borders.isChecked()

        # Only bail out completely when every visual element is disabled
        if not show_labels and not show_values and not show_borders:
            self.label_item.clear()
            return

        layer = self._active_layer()
        if not layer:
            self.label_item.clear()
            self.dock.set_status("No raster layer selected", "orange")
            return

        px_size = self._pixel_size_on_screen(layer)
        min_px  = self.dock.spin_min_px.value()
        if px_size < min_px:
            self.label_item.clear()
            self.dock.set_status(
                f"Zoom in — pixel is {px_size:.1f} screen px (need ≥ {min_px})", "orange"
            )
            return

        self.dock.set_status("Active — labels visible", "green")

        map_extent = self.canvas.extent()
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs  = layer.crs()
        raster_ext = layer.extent()
        res_x = layer.rasterUnitsPerPixelX()
        res_y = layer.rasterUnitsPerPixelY()

        if canvas_crs != layer_crs:
            xform = QgsCoordinateTransform(canvas_crs, layer_crs, QgsProject.instance())
            layer_extent = xform.transformBoundingBox(map_extent)
            xform_inv    = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())
        else:
            layer_extent = map_extent
            xform_inv    = None

        x0 = max(layer_extent.xMinimum(), raster_ext.xMinimum())
        x1 = min(layer_extent.xMaximum(), raster_ext.xMaximum())
        y0 = max(layer_extent.yMinimum(), raster_ext.yMinimum())
        y1 = min(layer_extent.yMaximum(), raster_ext.yMaximum())
        if x0 >= x1 or y0 >= y1:
            self.label_item.clear()
            return

        col_start = max(0, int((x0 - raster_ext.xMinimum()) / res_x))
        col_end   = min(layer.width(),  int((x1 - raster_ext.xMinimum()) / res_x) + 1)
        row_start = max(0, int((raster_ext.yMaximum() - y1) / res_y))
        row_end   = min(layer.height(), int((raster_ext.yMaximum() - y0) / res_y) + 1)

        n_rows = row_end - row_start
        n_cols = col_end - col_start
        if n_rows * n_cols > 2000:
            self.label_item.clear()
            self.dock.set_status(
                f"Too many pixels visible ({n_rows*n_cols}). Zoom in further.", "orange"
            )
            return

        mu_per_px = self.canvas.mapUnitsPerPixel()
        pw = res_x / mu_per_px
        ph = res_y / mu_per_px

        labels = []
        for row in range(row_start, row_end):
            for col in range(col_start, col_end):
                lx = raster_ext.xMinimum() + (col + 0.5) * res_x
                ly = raster_ext.yMaximum() - (row + 0.5) * res_y
                pt = QgsPointXY(lx, ly)
                if xform_inv:
                    pt = xform_inv.transform(pt)
                cx = (pt.x() - map_extent.xMinimum()) / mu_per_px
                cy = (map_extent.yMaximum() - pt.y()) / mu_per_px

                # Sample values only if needed for canvas display
                values = []
                if show_values:
                    values = self._get_pixel_values(layer, row, col)

                labels.append((cx, cy, row, col, values, pw, ph))

        self.label_item.set_labels(labels)
