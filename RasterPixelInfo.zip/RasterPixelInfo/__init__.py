# -*- coding: utf-8 -*-
def classFactory(iface):
    from .raster_pixel_info import RasterPixelInfo
    return RasterPixelInfo(iface)
